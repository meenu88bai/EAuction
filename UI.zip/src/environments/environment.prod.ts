export const environment = {
  production: true,
  apiServer: 'https://mseauctionsvc.azurewebsites.net/',
  imagePath: 'https://mseauctionsvc.azurewebsites.net/images/',
  titlePrefix: 'E Auction'
};
