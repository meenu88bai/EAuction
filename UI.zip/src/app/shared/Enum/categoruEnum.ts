export enum CategoryEnum {
  Car,House,Plot
}
